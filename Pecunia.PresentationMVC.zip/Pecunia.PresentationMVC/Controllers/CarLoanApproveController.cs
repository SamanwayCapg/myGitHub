﻿using Capgemini.Pecunia.BusinessLayer.LoanBL;
using Capgemini.Pecunia.Entities;
using Pecunia.PresentationMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;

namespace Pecunia.PresentationMVC.Controllers
{
    public class CarLoanApproveController : Controller
    {
        // GET: ApproveLoan
        public async Task<ActionResult> ListAllCarLoans()
        {
            List<CarLoan> carLoans = new List<CarLoan>();
            
            List<CarLoanViewModel> carLoanViewModels = new List<CarLoanViewModel>();
            
            CarLoanBL carLoanBL = new CarLoanBL();
            
            carLoans = await carLoanBL.ListAllLoansBL();
            
            foreach(CarLoan car in carLoans)
            {
                CarLoanViewModel carLoanViewModel = new CarLoanViewModel()
                {
                    LoanID = car.LoanID,
                    AmountApplied = car.AmountApplied,
                    InterestRate = car.InterestRate,
                    EMI_Amount = car.EMI_amount,
                    RepaymentPeriod = car.RepaymentPeriod,
                    DateOfApplication = car.DateOfApplication,
                    Status = car.LoanStatus,
                    Occupation = car.Occupation,
                    GrossIncome = car.GrossIncome,
                    SalaryDeductions = car.SalaryDeduction,
                    Vehicle = car.VehicleType
                };
                carLoanViewModels.Add(carLoanViewModel);
            }

            
            return View("ApproveCarLoan", carLoanViewModels);
        }

       
        //[Route("CarLoanApprove/UpdateStatus/{loanID}/{updatedStatus}")]
        public async Task<ActionResult> UpdateStatus(string loanID, string updatedStatus)
        {
            
            CarLoanBL carLoanBL = new CarLoanBL();
            List<CarLoan> carLoans = new List<CarLoan>();
            carLoans = await carLoanBL.ApproveLoanBL(loanID, updatedStatus);
            System.Diagnostics.Debug.WriteLine($"loanID:{loanID}, status:{updatedStatus}");

            if (carLoans.Count == 1)
            {
                return RedirectToAction("DisplayMessage", "ShowMessage", new { Message = "Status updated successfully!" });
            }
            else
            {
                return RedirectToAction("DisplayMessage", "ShowMessage", new { Message = "Internal error occured! Status can´t be updated to existing status" });
            }
        }


        public async Task<ActionResult> ListAllCarLoansToCancel()
        {
            List<CarLoan> carLoans = new List<CarLoan>();

            List<CarLoanViewModel> carLoanViewModels = new List<CarLoanViewModel>();

            CarLoanBL carLoanBL = new CarLoanBL();

            carLoans = await carLoanBL.ListAllLoansBL();

            foreach (CarLoan car in carLoans)
            {
                CarLoanViewModel carLoanViewModel = new CarLoanViewModel()
                {
                    LoanID = car.LoanID,
                    AmountApplied = car.AmountApplied,
                    InterestRate = car.InterestRate,
                    EMI_Amount = car.EMI_amount,
                    RepaymentPeriod = car.RepaymentPeriod,
                    DateOfApplication = car.DateOfApplication,
                    Status = car.LoanStatus,
                    Occupation = car.Occupation,
                    GrossIncome = car.GrossIncome,
                    SalaryDeductions = car.SalaryDeduction,
                    Vehicle = car.VehicleType
                };
                carLoanViewModels.Add(carLoanViewModel);
            }


            return View("CancelCarLoan", carLoanViewModels);
        }

        public async Task<ActionResult> CancelCarLoan(string loanID)
        {

            CarLoanBL carLoanBL = new CarLoanBL();
            List<CarLoan> carLoans = new List<CarLoan>();
            bool isDeleted = await carLoanBL.DeleteLoanEntryBL(loanID);
            //System.Diagnostics.Debug.WriteLine($"loanID:{loanID}, status:{updatedStatus}");

            if (isDeleted == true)
            {
                return RedirectToAction("DisplayMessage", "ShowMessage", new { Message = "Loan Cancelled Successfully!" });
            }
            else
            {
                return RedirectToAction("DisplayMessage", "ShowMessage", new { Message = "Internal error occured! Request cant be processed now, try again later!" });
            }
        }
    }
}