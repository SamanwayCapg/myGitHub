﻿using Capgemini.Pecunia.BusinessLayer.LoanBL;
using Capgemini.Pecunia.Entities;
using Pecunia.PresentationMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;

namespace Pecunia.PresentationMVC.Controllers
{
    public class EduLoanApproveController : Controller
    {
        // GET: EduLoanApprove
        public async Task<ActionResult> ListAllEduLoans()
        {
            List<EduLoan> eduLoans = new List<EduLoan>();
            List<EduLoanViewModel> eduLoanViewModels = new List<EduLoanViewModel>();
            EduLoanBL eduLoanBL = new EduLoanBL();
            eduLoans = await eduLoanBL.ListAllLoans();

            foreach (EduLoan edu in eduLoans)
            {
                EduLoanViewModel eduLoanViewModel = new EduLoanViewModel()
                {
                    LoanID = edu.LoanID,
                    AmountApplied = edu.AmountApplied,
                    InterestRate = edu.InterestRate,
                    EMI_Amount = edu.EMI_amount,
                    RepaymentPeriod = edu.RepaymentPeriod,
                    DateOfApplication = edu.DateOfApplication,
                    LoanStatus = edu.LoanStatus,
                    Course = edu.Course,
                    InstituteName = edu.InstituteName,
                    StudentID = edu.StudentID,
                    RepaymentHoliday = edu.RepaymentHoliday
                };
                eduLoanViewModels.Add(eduLoanViewModel);
            }

            return View();
        }
    }
}