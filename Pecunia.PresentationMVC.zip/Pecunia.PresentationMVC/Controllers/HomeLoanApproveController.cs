﻿using Capgemini.Pecunia.BusinessLayer.LoanBL;
using Capgemini.Pecunia.Entities;
using Pecunia.PresentationMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;

namespace Pecunia.PresentationMVC.Controllers
{
    public class HomeLoanApproveController : Controller
    {
        // GET: HomeLoanApprove
        public async Task<ActionResult> ListAllHomeLoans()
        {
            List<HomeLoan> homeLoans = new List<HomeLoan>();

            List<HomeLoanViewModel> homeLoanViewModels = new List<HomeLoanViewModel>();

            HomeLoanBL homeLoanBL = new HomeLoanBL();

            homeLoans = await homeLoanBL.ListAllLoansBL();

            foreach (HomeLoan loan in homeLoans)
            {
                HomeLoanViewModel homeLoanViewModel = new HomeLoanViewModel()
                {
                    LoanID = loan.LoanID,
                    AmountApplied = loan.AmountApplied,
                    InterestRate = loan.InterestRate,
                    EMI_Amount = loan.EMI_amount,
                    RepaymentPeriod = loan.RepaymentPeriod,
                    DateOfApplication = loan.DateOfApplication,
                    Status = loan.LoanStatus,
                    Occupation = loan.Occupation,
                    GrossIncome = loan.GrossIncome,
                    SalaryDeductions = loan.SalaryDeduction,
                    ServiceYears = loan.ServiceYears
                };
                homeLoanViewModels.Add(homeLoanViewModel);
            }
            return View();
        }
    }
}