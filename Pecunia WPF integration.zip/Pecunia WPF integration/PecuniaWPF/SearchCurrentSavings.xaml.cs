﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using Capgemini.Pecunia.Exceptions;

namespace PecuniaWPF
{
    /// <summary>
    /// Interaction logic for SearchCurrentSavings.xaml
    /// </summary>
    public partial class SearchCurrentSavings : Window
    {
        public SearchCurrentSavings()
        {
            InitializeComponent();
        }
        private void TxtGetAllResults_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //List of Accounts to be Displayed
                List<Account> accountList = new List<Account>();
                AccountBL accountBL = new AccountBL();
                accountList = accountBL.GetAllAccountsBL();

                //Putting List into Data Grid
                txtDataGrid.ItemsSource = accountList;
            }
            catch (Exception f)
            {
                MessageBox.Show(f.Message);
       
            }

        }

        private void TxtSearchByAccountID_Click(object sender, RoutedEventArgs e)
        {
            var temp = new SearchByAccountID();
            temp.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Close Current Window and Open a new Window
            var temp = new SearchOption();
            temp.Show();
            this.Close();
        }
    }
}
