﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using Capgemini.Pecunia.Exceptions;
namespace PecuniaWPF
{
    /// <summary>
    /// Interaction logic for AddCurrentSavings.xaml
    /// </summary>
    public partial class AddCurrentSavings : Window
    {
        public AddCurrentSavings()
        {
            InitializeComponent();
            Load();

        }
        private void txtName_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        /// <summary>
        ///   Creating Function To Add Account After Button is Clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            


           
            try
            {

                //Creating Object of Account 
                Account account = new Account();
                
                AccountBL accountBL = new AccountBL();
                account.HomeBranch = txtAccountBranch.Text;
                string accountType = txtAccountType.Text;
                if (txtCustomerIDList.SelectedValue == null)
                {
                    MessageBox.Show("select customerID");
                    //var temp = new AddOption();
                    //temp.Show();
                    //this.Close();
                }
                else
                {
                    Guid.TryParse((txtCustomerIDList.SelectedValue).ToString(), out Guid cust);
                    if (await accountBL.AddAccountBL(account, cust, accountType))
                    {
                        string Accid = account.AccountID.ToString();

                        MessageBox.Show("Account Added Successfully\n", Accid);
                        var temp = new AddOption();
                        temp.Show();
                        this.Close();

                    }
                    else

                    {
                        MessageBox.Show("Account Addition Failed");
                    }
                }
                    
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }








        }

        private void txtAccountType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        private void Back_Click(object sender, RoutedEventArgs e)
        {
            //Close Current Window and Open a new Window
            var temp = new AddOption();
            temp.Show();
            this.Close();
        }
        public void Load()
        {
           

        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

          

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            List<Account> acounts = new List<Account>();
            AccountBL accountBL = new AccountBL();
            acounts = accountBL.GetAllAccountsBL();
            CustomerBL customerBL = new CustomerBL();
            List<Customer> customers = new List<Customer>();
            customers = customerBL.GetAllCustomerDetailsBL();

            txtCustomerIDList.ItemsSource = customers;
            txtCustomerIDList.DisplayMemberPath = "CustomerName";
            txtCustomerIDList.SelectedValuePath = "CustomerID";

        }
    }
}
