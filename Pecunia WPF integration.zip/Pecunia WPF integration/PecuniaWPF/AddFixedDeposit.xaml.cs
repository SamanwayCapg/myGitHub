﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using Capgemini.Pecunia.Exceptions;

namespace PecuniaWPF
{
    /// <summary>
    /// Interaction logic for AddFixedDeposit.xaml
    /// </summary>
    public partial class AddFixedDeposit : Window
    {
        public AddFixedDeposit()
        {
            InitializeComponent();
        }

        /// <summary>
        ///  Creating Function To Add Fixed Deposit After Button is Clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Button_Click(object sender, RoutedEventArgs e)
        {

            //Creating Object of FixedDeposit 
            FixedDeposit fd = new FixedDeposit();
            fd.HomeBranch = txtAccountBranch.Text;
            
            
            try
            {
                bool isGuid = Guid.TryParse(txtCustomerID.Text, out Guid customerID);
                if (isGuid == false)
                {
                    MessageBox.Show("Invalid Guid");
                }
                fd.tenure = Convert.ToInt32(txtTenure.Text);
                fd.FdDeposit = Convert.ToDouble(txtInitialAmount.Text);
                FixedDepositBL fixedDepositBL = new FixedDepositBL();

                if (txtCustomerID.Text == null)
                    MessageBox.Show("select customerID");
                else
                {
                    if (await fixedDepositBL.AddFixedDepositBL(fd, customerID))
                    {

                        MessageBox.Show("Account Added Sucessfully");
                        var temp1 = new AddOption();
                        temp1.Show();
                        this.Close();

                    }
                    else
                        MessageBox.Show("Account Not Added");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

            var temp = new AddOption();
            temp.Show();
            this.Close();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            //Close Current Window and Open a new Window
            var temp = new AddOption();
            temp.Show();
            this.Close();
        }
    }
}
