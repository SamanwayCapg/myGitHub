﻿using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using Capgemini.Pecunia.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PecuniaWPF
{
    /// <summary>
    /// Interaction logic for Add.xaml
    /// </summary>
    public partial class AddCustomer : Window
    {
        public AddCustomer()
        {
            InitializeComponent();
        }

        private async void AddButton_Click(object sender, RoutedEventArgs e)
        {

            Customer customer = new Customer();
            CustomerBL customerBL = new CustomerBL();
            customer.CustomerName = txtName.Text;
            customer.CustomerAddress = txtAddress.Text;
            customer.CustomerMobile = txtMobile.Text;
            customer.CustomerEmail = txtEmail.Text;
            customer.CustomerPan = txtPAN.Text;
            customer.CustomerAadhaarNumber = txtAadhaar.Text;
            customer.DOB = txtDOB.Text;
            Gender gender;
            Enum.TryParse(cmbGender.Text, out gender);
            customer.CustomGender = gender;
            if (customer.CustomerName == "")
            {
                MessageBox.Show("Invalid Name");
            }
            else if (!Regex.IsMatch(customer.CustomerName, "[A-Za-z]"))
            {
                MessageBox.Show("Invalid Name");
            }



            else if (customer.CustomerEmail == "")
            {
                MessageBox.Show("Invalid Address");
            }
            else if (!Regex.IsMatch(customer.CustomerEmail, @" ^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9][a-zA-Z]"))
            {
                MessageBox.Show("Invalid Name");
            }

            else if (customer.CustomerAddress == "")
            {
                MessageBox.Show("Invalid Address");
            }
            else if (!Regex.IsMatch(customer.CustomerAddress, @"\d{1,3}.?\d{0,3}\s[a-zA-Z]{2,30}\s[a-zA-Z]{2,15}"))
            {
                MessageBox.Show("Invalid Name");
            }


            else if (customer.CustomerMobile.Length != 10)
            {
                MessageBox.Show("Invalid Mobile no");
            }
            else if (!Regex.IsMatch(customer.CustomerMobile, "^[0 - 9]{ 10}  $"))
            {
                MessageBox.Show("Invalid Mobile");
            }


            else if (customer.CustomerPan.Length != 10)
            {
                MessageBox.Show("Invalid Pan no");
            }
            else if (!Regex.IsMatch(customer.CustomerPan, "[^[a - zA - Z]{ 5}[0-9]{4} [a-zA-Z]{1}$]"))
            {
                MessageBox.Show("Invalid Pan");
            }


            else if (customer.CustomerAadhaarNumber.Length != 12)
            {
                MessageBox.Show("Invalid Aadhaar no");
            }
            else if (!Regex.IsMatch(customer.CustomerAadhaarNumber, "^([0-9]{12}"))
            {
                MessageBox.Show("Invalid Aadhaar no");
            }

            bool isAdded = await customerBL.AddCustomerBL(customer);

            if (isAdded == true)
                MessageBox.Show("Customer is addded");
            else
                MessageBox.Show("Customer is not added");

            var back = new CustomerMain();
            back.Show();
            this.Close();

        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            var back = new CustomerMain();
            back.Show();
            this.Close();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
