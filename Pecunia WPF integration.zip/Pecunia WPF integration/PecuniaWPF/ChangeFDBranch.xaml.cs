﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.Pecunia.Entities;
using Capgemini.Pecunia.BusinessLayer;

namespace PecuniaWPF
{
    /// <summary>
    /// Interaction logic for ChangeFDBranch.xaml
    /// </summary>
    public partial class ChangeFDBranch : Window
    {
        public ChangeFDBranch()
        {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            string homeBranch = txtAccountBranch.Text;
            Guid.TryParse(txtAccountID.Text, out Guid acc);
            FixedDeposit fixedDeposit = new FixedDeposit();
            FixedDepositBL fixedDepositBL = new FixedDepositBL();
            try
            {
                bool isAdded = await fixedDepositBL.ChangeBranchBL(acc, homeBranch);
                if (isAdded == true)
                {
                    MessageBox.Show("Branch Updated");
                    var temp = new UpdateFixedDeposit();
                    temp.Show();
                    this.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            //Close Current Window and Open a new Window
            var temp = new UpdateFixedDeposit();
            temp.Show();
            this.Close();
        }
    }
}
