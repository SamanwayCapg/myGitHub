﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.Pecunia.DataAccessLayer;
using System.IO;
using Newtonsoft.Json;
using Capgemini.Pecunia.Exceptions;
using Capgemini.Pecunia.Entities;
using Capgemini.Pecunia.Contracts.DALContracts;
using System.Data.SqlClient;
using System.Data;

using Capgemini.Pecunia.Helpers;

namespace Capgemini.Pecunia.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting Transaction from Transactions collection.
    /// </summary>
    [Serializable]
    public class TransactionDAL : TransactionDALBase, IDisposable
    {

        //public static List<Transaction> Transactions = new List<Transaction>() { };
        //public List<Transaction> TransactionsToSerialize = new List<Transaction>() { };
        //private string filepath = "Transactions.txt";

        /// <summary>
        /// Stores all transaction records to Transactions collection.
        /// </summary>
        /// <param name="accountID">Uniquely generated account ID.</param>
        /// <param name="amount">Amount to be transacted.</param>
        /// <param name="type">Type of transaction such as credit, debit.</param>
        /// <param name="mode">Mode of transaction such as cheque or withdrawal slip.</param>
        /// <param name="chequeNumber">Cheque number if mode of transaction is cheque and null in case of withdrawal slip.</param>
        /// <returns>Determinates whether the transactions are stored.</returns>
        public override bool StoreTransactionRecord(Guid accountID, double amount, TypeOfTransaction type,
            ModeOfTransaction mode, string chequeNumber)
        {
            bool storeTransaction = false;
            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            //SqlConnection conn = SQLServerUtil.getConnetion("Pecunia");
            try
            {
                conn.Open();
                Console.WriteLine("connected to the database");

                SqlCommand comm = new SqlCommand("TeamF.StoreTransactionRecords", conn);

                SqlParameter param1 = new SqlParameter("@accountID", accountID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;

                SqlParameter param2 = new SqlParameter("@type", type);
                param2.SqlDbType = SqlDbType.VarChar;

                SqlParameter param3 = new SqlParameter("@amount", amount);
                param3.SqlDbType = SqlDbType.Money;

                //Guid transactionID = Guid.NewGuid(); Console.WriteLine(transactionID);
                //SqlParameter param4 = new SqlParameter("@transactionID", transactionID);
                //param4.SqlDbType = SqlDbType.UniqueIdentifier;

                //DateTime dateOfTransaction = DateTime.Now;
                //SqlParameter param5 = new SqlParameter("@dateOfTransaction", dateOfTransaction);
                //param5.SqlDbType = SqlDbType.DateTime;

                SqlParameter param6 = new SqlParameter("@mode", mode);
                param6.SqlDbType = SqlDbType.VarChar;

                SqlParameter param7 = new SqlParameter("@chequeNumber", chequeNumber);
                param7.SqlDbType = SqlDbType.VarChar;


                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param2);
                Params.Add(param3);
                //Params.Add(param4);
                //Params.Add(param5);
                Params.Add(param6);
                Params.Add(param7);



                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();

                return storeTransaction;
                
            }

            catch (PecuniaException)
            {


                throw new StoreTransactionException("Transaction not stored.");
            }
        }

       
        /// <summary>
        /// Debit type of transaction with mode of transaction as withdrawal slip.
        /// </summary>
        /// <param name="accountID">Uniquely generated account ID.</param>
        /// <param name="amount">Amount to be debited.</param>       
        /// <returns>Determinates whether the amount is debited by withdrawal slip.</returns>
        public override bool DebitTransactionByWithdrawalSlipDAL(Guid accountID, double amount)
        {
            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            bool transactionWithdrawal = false;
            try
            {

                SqlCommand comm = new SqlCommand("TeamF.DebitBalance", conn);
                conn.Open();
                //Guid accID;
                //Guid.TryParse("bdc8e59d-f8ac-4cd6-92eb-4c3ed5baacf6", out accID);
                SqlParameter param1 = new SqlParameter("@accountID", accountID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;

                SqlParameter param3 = new SqlParameter("@amount", amount);
                param3.SqlDbType = SqlDbType.Money;

                //SqlParameter param3 = new SqlParameter("@amount", amount);
                //param3.SqlDbType = SqlDbType.Money;

                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param3);

                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();
               

                TypeOfTransaction typeOfTransaction;
                Enum.TryParse("Debit", out typeOfTransaction);
                ModeOfTransaction modeOfTransaction;
                Enum.TryParse("WithdrawalSlip", out modeOfTransaction);
                StoreTransactionRecord(accountID, amount, typeOfTransaction, modeOfTransaction, "000000");
                transactionWithdrawal = true;
                //accountDAL.SerialiazeIntoJSON(accounts, "AccountData.txt");


                return transactionWithdrawal;
            }
            catch (PecuniaException)
            {

                throw new InsufficientBalanceException("Insufficient Balance");
            }

        }

        /// <summary>
        /// Credit type of transaction with mode of transaction as withdrawal slip.
        /// </summary>
        /// <param name="accountID">Uniquely generated account ID.</param>
        /// <param name="amount">Amount to be credited.</param>       
        /// <returns>Determinates whether the amount is credited by withdrawal slip.</returns>
        public override bool CreditTransactionByDepositSlipDAL(Guid accountID, double amount)
        {

            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            bool transactionDeposit = false;
            try
            {
                SqlCommand comm = new SqlCommand("TeamF.CreditBalance", conn);
                conn.Open();
                
                SqlParameter param1 = new SqlParameter("@accountID", accountID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;

                SqlParameter param3 = new SqlParameter("@amount", amount);
                param3.SqlDbType = SqlDbType.Money;

                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param3);

                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();

                TypeOfTransaction typeOfTranscation;
                Enum.TryParse("Credit", out typeOfTranscation);
                ModeOfTransaction modeOfTransaction;
                Enum.TryParse("WithdrawalSlip", out modeOfTransaction);
                StoreTransactionRecord(accountID, amount, typeOfTranscation, modeOfTransaction, "000000");

                transactionDeposit = true;

                return transactionDeposit;
            }
            catch (PecuniaException)
            {
                throw new CreditSlipException("Transaction Failed");
            }
        }


        /// <summary>
        /// Debit type of transaction with mode of transaction as cheque.
        /// </summary>
        /// <param name="accountID">Uniquely generated account ID.</param>
        /// <param name="amount">Amount to be debited.</param>       
        /// <param name="chequeNumber">Cheque Number.</param>       
        /// <returns>Determinates whether the amount is debited by withdrawal slip.</returns>
        public override bool DebitTransactionByChequeDAL(Guid accountID, double amount, string chequeNumber)
        {
            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            bool transactionDebited = false;
            try


            {
                SqlCommand comm = new SqlCommand("TeamF.DebitBalance", conn);
                conn.Open();

                SqlParameter param1 = new SqlParameter("@accountID", accountID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;



                SqlParameter param2 = new SqlParameter("@amount", amount);
                param2.SqlDbType = SqlDbType.Money;



                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param2);

                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();


                TypeOfTransaction typeOfTranscation;
                Enum.TryParse("Debit", out typeOfTranscation);
                ModeOfTransaction modeOfTransaction;
                Enum.TryParse("Cheque", out modeOfTransaction);
                StoreTransactionRecord(accountID, amount, typeOfTranscation, modeOfTransaction, chequeNumber);

                transactionDebited = true;

                return transactionDebited;
            }
            catch (PecuniaException)
            {
                throw new DebitChequeException("Transaction Failed");
            }
        }


        /// <summary>
        /// Credit type of transaction with mode of transaction as cheque.
        /// </summary>
        /// <param name="accountID">Uniquely generated account ID.</param>
        /// <param name="amount">Amount to be credited.</param>      
        /// <param name="chequeNumber">Cheque Number.</param>                
        /// <returns>Determinates whether the amount is credited by cheque.</returns>
        public override bool CreditTransactionByChequeDAL(Guid accountID, double amount, string chequeNumber)
        {
            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            bool transactionCredited = false;
            try
            {
                SqlCommand comm = new SqlCommand("TeamF.CreditBalance", conn);
                conn.Open();

                SqlParameter param1 = new SqlParameter("@accountID", accountID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;


                SqlParameter param2 = new SqlParameter("@amount", amount);
                param2.SqlDbType = SqlDbType.Money;



                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param2);


                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();
                TypeOfTransaction typeOfTranscation;
                Enum.TryParse("Credit", out typeOfTranscation);
                ModeOfTransaction modeOfTransaction;
                Enum.TryParse("Cheque", out modeOfTransaction);
                StoreTransactionRecord(accountID, amount, typeOfTranscation, modeOfTransaction, chequeNumber);
                transactionCredited = true;
                return transactionCredited;
            }

            catch (PecuniaException)
            {
                throw new CreditChequeException("Transaction Failed");
            }
        }

        /// <summary>
        /// Displays all transactions for a particular account ID.
        /// </summary>
        /// <param name="accountID">Uniquely generated account ID.</param>
        /// <returns>Provides a list of transactions for a particular account ID.</returns>
        public override List<Transaction> DisplayTransactionByAccountIDDAL(Guid accountID)
        {

            List<Transaction> transactions = new List<Transaction>();
            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");


            try
            {

                SqlCommand comm = new SqlCommand("TeamF.GetTransactionsByAccountID", conn);
                conn.Open();


                SqlParameter param2 = new SqlParameter("@accountID", accountID);
                param2.SqlDbType = SqlDbType.UniqueIdentifier;

                List<SqlParameter> Params = new List<SqlParameter>();

                Params.Add(param2);

                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();


                SqlDataReader sql = comm.ExecuteReader();

                if (sql.HasRows)
                {
                    while (sql.Read())
                    {
                        Transaction objToReturn = new Transaction();
                        objToReturn = getNetDataTypes(sql, objToReturn);
                        transactions.Add(objToReturn);
                    }
                }
                else
                {
                    return transactions;
                }
                sql.Close();

                conn.Close();
                return transactions;

            }
            catch (PecuniaException)
            {
                throw new TransactionDisplayIDException("Transaction Failed");
                
            }
        }

        Transaction getNetDataTypes(SqlDataReader sql, Transaction objToReturn)
        {
            objToReturn.TransactionID = sql.GetGuid(0);
            objToReturn.AccountID = sql.GetGuid(1);

            TypeOfTransaction typeOfTransaction;
            Enum.TryParse(sql.GetString(2), out typeOfTransaction);
            objToReturn.Type = typeOfTransaction;

            objToReturn.Amount = Convert.ToDouble(sql.GetDecimal(3));
            objToReturn.DateOfTransaction = sql.GetDateTime(4);

            ModeOfTransaction modeOfTransaction;
            Enum.TryParse(sql.GetString(5), out modeOfTransaction);
            objToReturn.Mode = modeOfTransaction;

            objToReturn.ChequeNumber = sql.GetString(6);
            return objToReturn;


        }
        
        /// <summary>
        /// Gets all Transactions from the collection.
        /// </summary>
        /// <returns>Returns list of all Transactions.</returns>
        public override DataSet GetAllTransactionsDAL()
        {
            Transaction getAll = new Transaction();

            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            SqlDataAdapter dataAdapter = new SqlDataAdapter("select*from TeamF.GetAllTransactions", conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds);
            return ds;
        }

       
        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }

    }
}
