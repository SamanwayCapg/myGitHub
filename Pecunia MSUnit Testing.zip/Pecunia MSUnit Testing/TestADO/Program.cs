﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.Pecunia.Helpers;
using System.Data.SqlClient;
using System.Data;

namespace TestADO
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conn = SQLServerUtil.getConnetion("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            try
            {
                conn.Open();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            //SqlCommand cmd = new SqlCommand("TeamF.applyCarLoan", conn);
            //cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@LoanID", new Guid());
            //cmd.Parameters.AddWithValue("@CustomerID", new Guid());
            //cmd.Parameters.AddWithValue("@AmountApplied", 120000);
            //cmd.Parameters.AddWithValue("@InterestRate", 10.65);
            //cmd.Parameters.AddWithValue("@EMI_amount", 1458.25);
            //cmd.Parameters.AddWithValue("@RepaymentPeriod", 25);
            //cmd.Parameters.AddWithValue("@DateOfApplication", "2015-10-25");
            //cmd.Parameters.AddWithValue("@LoanStatus", "ÄPPLIED");
            //cmd.Parameters.AddWithValue("@Occupation", "SERVICE");
            //cmd.Parameters.AddWithValue("@GrossIncome", 52000);
            //cmd.Parameters.AddWithValue("@SalaryDeduction", 2500);
            //cmd.Parameters.AddWithValue("@VehicleType", "OTHERS");

            string name = "asdfas";
            SqlCommand cmd = new SqlCommand("TeamF.AddCustomerDAL", conn);

            Guid myguid = Guid.NewGuid();
            cmd.Parameters.AddWithValue("@CustomerID", SqlDbType.UniqueIdentifier).Value = new Guid("99EAC132-A1AE-41A9-B835-C7DC704A0450");
            cmd.Parameters.AddWithValue("@CustomerName", SqlDbType.VarChar).Value = "Akshay";
            cmd.Parameters.AddWithValue("@CustomerAddress", SqlDbType.VarChar).Value = "mumbai";
            cmd.Parameters.AddWithValue("@CustomerMobile", SqlDbType.Char).Value = "9933558877";
            cmd.Parameters.AddWithValue("@CustomerEmail", SqlDbType.VarChar).Value = "adsf@gmai.com";
            cmd.Parameters.AddWithValue("@CustomerPAN", SqlDbType.Char).Value = "DERTF3645D";
            cmd.Parameters.AddWithValue("@CustomerAadharNumber", SqlDbType.Char).Value = "123698547895";
            cmd.Parameters.AddWithValue("@DOB", SqlDbType.DateTime).Value = "2015-12-25";
            cmd.Parameters.AddWithValue("@CustomerGender", SqlDbType.VarChar).Value = "Male";
            cmd.ExecuteNonQuery();
            conn.Close();

     
        }
    }
}
