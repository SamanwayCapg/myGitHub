﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.Pecunia.Helpers;
using System.Data.SqlClient;
using System.Data;

namespace TestADO
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conn = SQLServerUtil.getConnetion("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            try
            {
                conn.Open();
                Console.WriteLine("connected");
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            SqlCommand comm = new SqlCommand("TeamF.approveHomeLoan", conn);

            string LoanID = "9ED2ED8A-DF65-433F-A395-1B0968DD388D";
            Guid loanID;
            Guid.TryParse(LoanID, out loanID);
            SqlParameter param1 = new SqlParameter("@LoanID", loanID);
            param1.SqlDbType = SqlDbType.UniqueIdentifier;

            SqlParameter param2 = new SqlParameter("@updatedStatus", "APPROVED");

            List<SqlParameter> Params = new List<SqlParameter>();
            Params.Add(param1);
            Params.Add(param2);
            comm.Parameters.AddRange(Params.ToArray());
            comm.CommandType = CommandType.StoredProcedure;
            comm.ExecuteNonQuery();
            Console.WriteLine("updated");

            comm = new SqlCommand($"select * from TeamF.HomeLoan where LoanID='{loanID}'", conn);

            SqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                if (reader == null)
                    reader.Close();
                else
                {
                    Console.WriteLine(reader.GetValue(0));
                    Console.WriteLine(reader.GetValue(1));
                }

            }
            conn.Close();

        }
    }
}
