﻿using System.Collections.Generic;
using Capgemini.Pecunia.Entities;
using Newtonsoft.Json;
using System.IO;
using System;
using Pecunia.Contracts.DALcontracts.LoanDALBase;
using Capgemini.Pecunia.Helpers;
using System.Data.SqlClient;
using System.Data;

namespace Capgemini.Pecunia.DataAccessLayer.LoanDAL
{
    public class CarLoanDAL : CarLoanDALBase, IDisposable
    {
        public static List<CarLoan> CarLoans;
        public override bool  ApplyLoanDAL(CarLoan car)
        {

            SqlConnection conn = SQLServerUtil.getConnetion("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            //SqlConnection conn = SQLServerUtil.getConnetion("Pecunia");
            try
            {
                conn.Open();
                

                SqlCommand comm = new SqlCommand("TeamF.applyCarLoan", conn);

                Guid loanID = Guid.NewGuid(); 
                SqlParameter param1 = new SqlParameter("@LoanID", loanID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;

                //Guid customerID;
                //Guid.TryParse(car.CustomerID, out customerID);
                SqlParameter param2 = new SqlParameter("@CustomerID", car.CustomerID);
                param2.SqlDbType = SqlDbType.UniqueIdentifier;

                SqlParameter param3 = new SqlParameter("@AmountApplied", car.AmountApplied);
                param3.SqlDbType = SqlDbType.Money;

                SqlParameter param4 = new SqlParameter("@InterestRate", car.InterestRate);
                param4.SqlDbType = SqlDbType.Money;

                SqlParameter param5 = new SqlParameter("@EMI_amount", car.EMI_Amount);
                param5.SqlDbType = SqlDbType.Money;

                SqlParameter param6 = new SqlParameter("@RepaymentPeriod", car.RepaymentPeriod);
                param6.SqlDbType = SqlDbType.TinyInt;

                DateTime dateOfApplication = DateTime.Now;
                SqlParameter param7 = new SqlParameter("@DateOfApplication", dateOfApplication);
                param7.SqlDbType = SqlDbType.DateTime;

                SqlParameter param8 = new SqlParameter("@LoanStatus", car.Status);
                param8.SqlDbType = SqlDbType.VarChar;

                SqlParameter param9 = new SqlParameter("@Occupation", car.Occupation);
                param9.SqlDbType = SqlDbType.VarChar;

                SqlParameter param10 = new SqlParameter("@GrossIncome", car.GrossIncome);
                param10.SqlDbType = SqlDbType.Money;

                SqlParameter param11 = new SqlParameter("@SalaryDeduction", car.SalaryDeductions);
                param11.SqlDbType = SqlDbType.Money;

                SqlParameter param12 = new SqlParameter("@VehicleType", car.Vehicle);
                param12.SqlDbType = SqlDbType.VarChar;

                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param2);
                Params.Add(param3);
                Params.Add(param4);
                Params.Add(param5);
                Params.Add(param6);
                Params.Add(param7);
                Params.Add(param8);
                Params.Add(param9);
                Params.Add(param10);
                Params.Add(param11);
                Params.Add(param12);

                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.Message); Console.ReadKey();
                BusinessLogicUtil.PecuniaLogException("applyCarLoan", e.Message);
                return false;
            }


        }

        public override CarLoan ApproveLoanDAL(string loanID, LoanStatus updatedStatus)
        {
            //List<CarLoan> carLoans = DeserializeFromJSON("CarLoans.txt");
            CarLoan objToReturn = new CarLoan();

            return objToReturn;
        }

        public override CarLoan GetLoanByCustomerIDDAL(string customerID)
        {
            List<CarLoan> carLoans = DeserializeFromJSON("CarLoans.txt");
            Guid customerIDGuid;
            bool isValidGuid = Guid.TryParse(customerID, out customerIDGuid);

            if (isValidGuid == true)
            {
                foreach (CarLoan Loan in carLoans)
                {
                    if (customerIDGuid == Loan.CustomerID)
                        return Loan;
                }
            }
            return default(CarLoan);
        }

        public override CarLoan GetLoanByLoanIDDAL(string loanID)
        {
            List<CarLoan> carLoans = DeserializeFromJSON("CarLoans.txt");
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (CarLoan Loan in carLoans)
                {
                    if (loanIDGuid == Loan.LoanID)
                        return Loan;
                }
            }
            return default(CarLoan);
        }

        public override LoanStatus GetLoanStatusDAL(string loanID)
        {
            List<CarLoan> carLoans = DeserializeFromJSON("CarLoans.txt");
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (CarLoan Loan in carLoans)
                {
                    if (loanIDGuid == Loan.LoanID)
                        return Loan.Status;
                }
            }

            return (LoanStatus)4;//LoanStatus for INVALID 
        }

        public static List<CarLoan> DeserializeFromJSON(string FileName)
        {
            List<CarLoan> carLoans = JsonConvert.DeserializeObject<List<CarLoan>>(File.ReadAllText(FileName));// Done to read data from file
            return carLoans;
        }

        public static bool SerializeIntoJSON(List<CarLoan> CarLoans, string fileName)
        {
            try
            {
                JsonSerializer serializer = new JsonSerializer();
                using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
                using (StreamWriter sw = new StreamWriter(fs))   //filename is used so that we can have access over our own file
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, CarLoans);
                    sw.Close();
                    fs.Close();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public override List<CarLoan> ListAllLoansDAL()
        {
            List<CarLoan> carLoans = DeserializeFromJSON("CarLoans.txt");
            return carLoans;
        }

        public override bool IsLoanIDExistDAL(string loanID)
        {
            List<CarLoan> loans = DeserializeFromJSON("CarLoans.txt");

            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (var loan in loans)
                {
                    if (loanIDGuid == loan.LoanID)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}
