﻿using System.Collections.Generic;
using Capgemini.Pecunia.Entities;
using Newtonsoft.Json;
using System.IO;
using System;
using Capgemini.Pecunia.Contracts.DALcontracts.LoanDALBase;
using System.Data.SqlClient;
using System.Data;
using Capgemini.Pecunia.Helpers;

namespace Capgemini.Pecunia.DataAccessLayer.LoanDAL
{
    /// <summary>
    /// Contains data access layer methods for validating, inserting, updating, deleting Home Loan from Home Loans collection.
    /// </summary>
    public class HomeLoanDAL : HomeLoanDALBase, IDisposable
    {
        public static List<HomeLoan> HomeLoans = new List<HomeLoan>();

        /// <summary>
        /// Validation before applying a new loan.
        /// </summary>
        /// <param name="HomeLoan">Represents home loan object that contains details of home loan.</param>
        /// <returns>Returns a boolean value, that indicates whether loan is applied or not.</returns>
        public override bool ApplyLoanDAL(HomeLoan home)
        {

            //var loanList = DeserializeFromJSON(fileName);
            //loanList.Add(home);
            //return SerializeIntoJSON(loanList, fileName);

            SqlConnection conn = SQLServerUtil.getConnetion("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            //SqlConnection conn = SQLServerUtil.getConnetion("Pecunia");
            try
            {
                conn.Open();


                SqlCommand comm = new SqlCommand("TeamF.applyHomeLoan", conn);

                Guid loanID = Guid.NewGuid();
                SqlParameter param1 = new SqlParameter("@LoanID", loanID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;

                //Guid customerID;
                //Guid.TryParse(car.CustomerID, out customerID);
                SqlParameter param2 = new SqlParameter("@CustomerID", home.CustomerID);
                param2.SqlDbType = SqlDbType.UniqueIdentifier;

                SqlParameter param3 = new SqlParameter("@AmountApplied", home.AmountApplied);
                param3.SqlDbType = SqlDbType.Money;

                SqlParameter param4 = new SqlParameter("@InterestRate", home.InterestRate);
                param4.SqlDbType = SqlDbType.Money;

                SqlParameter param5 = new SqlParameter("@EMI_amount", home.EMI_Amount);
                param5.SqlDbType = SqlDbType.Money;

                SqlParameter param6 = new SqlParameter("@RepaymentPeriod", home.RepaymentPeriod);
                param6.SqlDbType = SqlDbType.TinyInt;

                DateTime dateOfApplication = DateTime.Now;
                SqlParameter param7 = new SqlParameter("@DateOfApplication", dateOfApplication);
                param7.SqlDbType = SqlDbType.DateTime;

                SqlParameter param8 = new SqlParameter("@LoanStatus", home.Status);
                param8.SqlDbType = SqlDbType.VarChar;

                SqlParameter param9 = new SqlParameter("@Occupation", home.Occupation);
                param9.SqlDbType = SqlDbType.VarChar;

                SqlParameter param10 = new SqlParameter("@ServiceYears", home.ServiceYears);
                param10.SqlDbType = SqlDbType.TinyInt;

                SqlParameter param11 = new SqlParameter("@GrossIncome", home.GrossIncome);
                param11.SqlDbType = SqlDbType.Money;

                SqlParameter param12 = new SqlParameter("@SalaryDeduction", home.SalaryDeductions);
                param12.SqlDbType = SqlDbType.Money;

                

                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param2);
                Params.Add(param3);
                Params.Add(param4);
                Params.Add(param5);
                Params.Add(param6);
                Params.Add(param7);
                Params.Add(param8);
                Params.Add(param9);
                Params.Add(param10);
                Params.Add(param11);
                Params.Add(param12);

                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.Message);
                //Console.ReadKey();
                BusinessLogicUtil.PecuniaLogException("applyHomeLoan", e.Message);
                return false;
            }
        }

        /// <summary>
        /// For approving loan.
        /// </summary>
        /// <param name="loanID">Represents Loan ID.</param>
        /// <param name="updatedStatus">Represents Updated Loan Status.</param>
        /// <returns>Returns Home loan object.</returns>
        public override HomeLoan ApproveLoanDAL(string loanID, LoanStatus updatedStatus)
        {
            
            

            SqlConnection conn = SQLServerUtil.getConnetion("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            try
            {
                conn.Open();
                Console.WriteLine("connected");
                SqlCommand comm = new SqlCommand("TeamF.approveHomeLoan", conn);

                Guid LoanID;
                Guid.TryParse(loanID, out LoanID);
                SqlParameter param1 = new SqlParameter("@LoanID", LoanID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;

                SqlParameter param2 = new SqlParameter("@updatedStatus", updatedStatus);
                param2.SqlDbType = SqlDbType.VarChar;

                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param2);
                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                

                HomeLoan objToReturn = new HomeLoan();
                comm = new SqlCommand($"select * from TeamF.HomeLoan where LoanID='{loanID}'", conn);

                SqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    if (reader == null)
                        reader.Close();
                    else
                    {

                        objToReturn.LoanID = reader.GetGuid(0);
                        Console.WriteLine("LoanID:"+objToReturn.LoanID);
                        objToReturn.CustomerID = reader.GetGuid(1);
                        Console.WriteLine("CustomerID:" + objToReturn.CustomerID);
                        objToReturn.AmountApplied = reader.GetDouble;
                        Console.WriteLine("LoanID:" + objToReturn.AmountApplied);
                        objToReturn.InterestRate = (double)reader.GetValue(3);
                        Console.WriteLine("LoanID:" + objToReturn.InterestRate);
                        objToReturn.EMI_Amount = (double)reader.GetValue(4);
                        Console.WriteLine("LoanID:" + objToReturn.EMI_Amount);
                        objToReturn.RepaymentPeriod = (int)reader.GetValue(5);
                        Console.WriteLine("LoanID:" + objToReturn.RepaymentPeriod);
                        objToReturn.DateOfApplication = (System.DateTime)reader.GetValue(6);
                        Console.WriteLine("LoanID:" + objToReturn.DateOfApplication);
                        objToReturn.Status = (LoanStatus)reader.GetValue(7);
                        Console.WriteLine("LoanID:" + objToReturn.Status);
                        objToReturn.Occupation = (ServiceType)reader.GetValue(8);
                        Console.WriteLine("LoanID:" + objToReturn.Occupation);
                        objToReturn.ServiceYears = (int)reader.GetValue(9);
                        Console.WriteLine("LoanID:" + objToReturn.ServiceYears);
                        objToReturn.GrossIncome = (double)reader.GetValue(10);
                        Console.WriteLine("LoanID:" + objToReturn.GrossIncome);
                        objToReturn.SalaryDeductions = (double)reader.GetValue(11);
                        Console.WriteLine("LoanID:" + objToReturn.SalaryDeductions);
                    }

                }
                conn.Close();
                return objToReturn;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.ReadKey();
                return default(HomeLoan);
            }

            
        }

        /// <summary>
        /// For displaying loan for specific customer ID.
        /// </summary>
        /// <param name="customerID">Represents Customer ID.</param>
        /// <returns>Returns Home Loan for Customer.</returns>
        public override HomeLoan GetLoanByCustomerIDDAL(string customerID)
        {
            List<HomeLoan> HomeLoans = DeserializeFromJSON(fileName);
            Guid customerIDGuid;
            bool isValidGuid = Guid.TryParse(customerID, out customerIDGuid);

            if (isValidGuid == true)
            {
                foreach (HomeLoan Loan in HomeLoans)
                {
                    if (Guid.Parse(customerID) == Loan.CustomerID)
                        return Loan;
                }
            }
            return default(HomeLoan);
        }

        /// <summary>
        /// Gets Loan by Loan ID.
        /// </summary>
        /// <param name="loanID">Represents Loan ID.</param>
        /// <returns>Returns Home loan object.</returns>
        public override HomeLoan GetLoanByLoanIDDAL(string loanID)
        {
            List<HomeLoan> HomeLoans = DeserializeFromJSON(fileName);
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (HomeLoan Loan in HomeLoans)
                {
                    if (Guid.Parse(loanID) == Loan.LoanID)
                        return Loan;
                }
            }
            return default(HomeLoan);
        }

        /// <summary>
        /// For displaying loan status.
        /// </summary>
        /// <param name="loanID">Represents Loan ID.</param>
        /// <returns>Returns Loan Status for Loans.</returns>
        public override LoanStatus GetLoanStatusDAL(string loanID)
        {
            List<HomeLoan> HomeLoans = DeserializeFromJSON(fileName);
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (HomeLoan Loan in HomeLoans)
                {
                    if (Guid.Parse(loanID) == Loan.LoanID)
                        return Loan.Status;
                }
            }
            return (LoanStatus)4;//LoanStatus for INVALID 
        }

        public static List<HomeLoan> DeserializeFromJSON(string fileName)
        {
            List<HomeLoan> HomeLoans = JsonConvert.DeserializeObject<List<HomeLoan>>(File.ReadAllText(fileName));// Done to read data from file
            return HomeLoans;
        }

        public static bool SerializeIntoJSON(List<HomeLoan> CarLoans, string fileName)
        {
            try
            {
                JsonSerializer serializer = new JsonSerializer();
                using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
                using (StreamWriter sw = new StreamWriter(fs))   //filename is used so that we can have access over our own file
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, CarLoans);
                    sw.Close();
                    fs.Close();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Lists all Loans.
        /// </summary>    
        /// <returns>Returns list of Home loan objects.</returns>
        public override List<HomeLoan> ListAllLoansDAL()
        {
            List<HomeLoan> HomeLoans = DeserializeFromJSON(fileName);
            return HomeLoans;
        }

        /// <summary>
        /// Checks if a particular loan ID exists.
        /// </summary>    
        /// <returns>Returns bool value to know if loan ID exists or not.</returns>
        public override bool IsLoanIDExistDAL(string loanID)
        {
            List<HomeLoan> loans = DeserializeFromJSON(fileName);
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (var loan in loans)
                {
                    //if (loan.LoanID.Equals(loanID))
                    if (Guid.Parse(loanID) == loan.LoanID)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}
