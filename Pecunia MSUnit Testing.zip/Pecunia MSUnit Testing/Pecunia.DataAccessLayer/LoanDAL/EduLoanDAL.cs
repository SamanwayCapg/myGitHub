﻿using System.Collections.Generic;
using Capgemini.Pecunia.Entities;
using Newtonsoft.Json;
using System.IO;
using System;
using Capgemini.Pecunia.Contracts.DALcontracts.LoanDALBase;
using System.Data.SqlClient;
using System.Data;
using Capgemini.Pecunia.Helpers;

namespace Capgemini.Pecunia.DataAccessLayer.LoanDAL
{
    public class EduLoanDAL : EduLoanDALBase, IDisposable
    {
        public static List<EduLoan> EduLoans;

        public override bool ApplyLoanDAL(EduLoan edu)
        {

            SqlConnection conn = SQLServerUtil.getConnetion("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");
            //SqlConnection conn = SQLServerUtil.getConnetion("Pecunia");
            try
            {
                conn.Open();


                SqlCommand comm = new SqlCommand("TeamF.applyEduLoan", conn);

                Guid loanID = Guid.NewGuid();
                SqlParameter param1 = new SqlParameter("@LoanID", loanID);
                param1.SqlDbType = SqlDbType.UniqueIdentifier;

                //Guid customerID;
                //Guid.TryParse(car.CustomerID, out customerID);
                SqlParameter param2 = new SqlParameter("@CustomerID", edu.CustomerID);
                param2.SqlDbType = SqlDbType.UniqueIdentifier;

                SqlParameter param3 = new SqlParameter("@AmountApplied", edu.AmountApplied);
                param3.SqlDbType = SqlDbType.Money;

                SqlParameter param4 = new SqlParameter("@InterestRate", edu.InterestRate);
                param4.SqlDbType = SqlDbType.Money;

                SqlParameter param5 = new SqlParameter("@EMI_amount", edu.EMI_Amount);
                param5.SqlDbType = SqlDbType.Money;

                SqlParameter param6 = new SqlParameter("@RepaymentPeriod", edu.RepaymentPeriod);
                param6.SqlDbType = SqlDbType.TinyInt;

                DateTime dateOfApplication = DateTime.Now;
                SqlParameter param7 = new SqlParameter("@DateOfApplication", dateOfApplication);
                param7.SqlDbType = SqlDbType.DateTime;

                SqlParameter param8 = new SqlParameter("@LoanStatus", edu.Status);
                param8.SqlDbType = SqlDbType.VarChar;

                SqlParameter param9 = new SqlParameter("@Course", edu.Course);
                param9.SqlDbType = SqlDbType.VarChar;

                SqlParameter param10 = new SqlParameter("@InstituteName", edu.InstituteName);
                param10.SqlDbType = SqlDbType.VarChar;

                SqlParameter param11 = new SqlParameter("@StudentID", edu.StudentID);
                param11.SqlDbType = SqlDbType.VarChar;

                SqlParameter param12 = new SqlParameter("@RepaymentHoliday", edu.RepaymentPeriod);
                param12.SqlDbType = SqlDbType.TinyInt;

                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(param1);
                Params.Add(param2);
                Params.Add(param3);
                Params.Add(param4);
                Params.Add(param5);
                Params.Add(param6);
                Params.Add(param7);
                Params.Add(param8);
                Params.Add(param9);
                Params.Add(param10);
                Params.Add(param11);
                Params.Add(param12);

                comm.Parameters.AddRange(Params.ToArray());
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                BusinessLogicUtil.PecuniaLogException("applyEduLoan", e.Message);
                return false;
            }

        }

        public override EduLoan ApproveLoanDAL(string loanID, LoanStatus updatedStatus)
        {
            List<EduLoan> eduLoans = DeserializeFromJSON("EduLoans.txt");
            EduLoan objToReturn = new EduLoan();
            foreach (EduLoan Loan in eduLoans)
            {
                if (Guid.Parse(loanID) == Loan.LoanID)
                {
                    Loan.Status = updatedStatus;
                    objToReturn = Loan;
                    break;
                }
            }

            SerializeIntoJSON(eduLoans, "EduLoans.txt");
            return objToReturn;
        }

        public override EduLoan GetLoanByCustomerIDDAL(string customerID)
        {
            List<EduLoan> eduLoans = DeserializeFromJSON("EduLoans.txt");
            Guid customerIDGuid;
            bool isValidGuid = Guid.TryParse(customerID, out customerIDGuid);

            if (isValidGuid == true)
            {
                foreach (EduLoan Loan in eduLoans)
                {
                    if (Guid.Parse(customerID) == Loan.CustomerID)
                        return Loan;
                }
            }
            return default(EduLoan);
        }

        public override EduLoan GetLoanByLoanIDDAL(string loanID)
        {
            List<EduLoan> eduLoans = DeserializeFromJSON("EduLoans.txt");
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (EduLoan Loan in eduLoans)
                {
                    if (Guid.Parse(loanID) == Loan.LoanID)
                        return Loan;
                }
            }
            return default(EduLoan);
        }

        public override LoanStatus GetLoanStatusDAL(string loanID)
        {
            List<EduLoan> eduLoans = DeserializeFromJSON("EduLoans.txt");
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (EduLoan Loan in eduLoans)
                {
                    if (Guid.Parse(loanID) == Loan.LoanID)
                        return Loan.Status;
                }
            }
            return (LoanStatus)4;//LoanStatus for INVALID
        }

        public static List<EduLoan> DeserializeFromJSON(string FileName)
        {
            List<EduLoan> eduLoans = JsonConvert.DeserializeObject<List<EduLoan>>(File.ReadAllText(FileName));// Done to read data from file
            return eduLoans;
        }

        public static bool SerializeIntoJSON(List<EduLoan> eduLoans, string fileName)
        {
            try
            {
                JsonSerializer serializer = new JsonSerializer();
                using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
                using (StreamWriter sw = new StreamWriter(fs))   //filename is used so that we can have access over our own file
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, eduLoans);
                    sw.Close();
                    fs.Close();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public override List<EduLoan> ListAllLoansDAL()
        {
            List<EduLoan> eduLoans = DeserializeFromJSON("EduLoans.txt");
            return eduLoans;
        }

        public override bool IsLoanIDExistDAL(string loanID)
        {
            List<EduLoan> loans = DeserializeFromJSON("EduLoans.txt");
            Guid loanIDGuid;
            bool isValidGuid = Guid.TryParse(loanID, out loanIDGuid);

            if (isValidGuid == true)
            {
                foreach (var loan in loans)
                {
                    if (Guid.Parse(loanID) == loan.LoanID)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }


    }
}
