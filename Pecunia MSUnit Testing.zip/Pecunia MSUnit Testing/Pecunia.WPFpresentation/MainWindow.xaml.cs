﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pecunia.WPFpresentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        

        private void ApplyHomeLoan_Click(object sender, RoutedEventArgs e)
        {
            var applyHomeLoanHome = new ApplyHomeLoan();
            applyHomeLoanHome.Show();
            this.Close();
        }

        private void Button_Click_ApplyCarLoan(object sender, RoutedEventArgs e)
        {
            var applyCarLoanHome = new ApplyCarLoan();
            applyCarLoanHome.Show();
            this.Close();
        }

        private void ApplyEduLoan_Click(object sender, RoutedEventArgs e)
        {
            var applyEduLoanHome = new ApplyEduLoan();
            applyEduLoanHome.Show();
            this.Close();
        }

        private void ApproveCarLoan_Click(object sender, RoutedEventArgs e)
        {
            var approveCarLoan = new ApproveCarLoan();
            approveCarLoan.Show();
            this.Close();
        }

        private void ApproveHomeLoan_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ApproveEduLoan_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SearchLoanBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
