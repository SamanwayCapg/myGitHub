﻿using Capgemini.Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pecunia.WPFpresentation
{
    /// <summary>
    /// Interaction logic for ApproveCarLoan.xaml
    /// </summary>
    public partial class ApproveCarLoan : Window
    {
        public ApproveCarLoan()
        {
            InitializeComponent();
            txtBlock.Text = "Samanway";
            CarLoan car = new CarLoan
            {
                AmountApplied = 120000,
                CustomerID = Guid.NewGuid(),
                DateOfApplication = DateTime.Now,
                EMI_Amount = 120,
                GrossIncome = 1548,
                InterestRate = 12.23,
                LoanID = Guid.NewGuid(),
                Occupation = (ServiceType)0,
                RepaymentPeriod = 12,
                SalaryDeductions = 1254,
                Status = (LoanStatus)0,
                Vehicle = (VehicleType)0
            };

            List<CarLoan> cars = new List<CarLoan>();
            cars.Add(car);
            txtlock.ItemsSource = cars;
        }
        

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //CarLoan car = new CarLoan
            //{
            //    AmountApplied = 120000,
            //    CustomerID = Guid.NewGuid(),
            //    DateOfApplication = DateTime.Now,
            //    EMI_Amount = 120,
            //    GrossIncome = 1548,
            //    InterestRate = 12.23,
            //    LoanID = Guid.NewGuid(),
            //    Occupation = (ServiceType)0,
            //    RepaymentPeriod = 12,
            //    SalaryDeductions = 1254,
            //    Status = (LoanStatus)0,
            //    Vehicle = (VehicleType)0
            //};

            //List<CarLoan> cars = new List<CarLoan>();
            //cars.Add(car);
            //txtlock.ItemsSource = cars;
        }
    }
}
