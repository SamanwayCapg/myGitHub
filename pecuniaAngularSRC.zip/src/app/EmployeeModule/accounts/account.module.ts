import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AccountRoutingModule } from './account-routing.module';
import {StartComponent} from './Component/start.component';
import { HttpClientModule } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PecuniaDataService } from '../../InMemoryWebAPIServices/employees-data.service';
import { AccountsComponent } from './Account/accounts.component';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: 
  [
      StartComponent,
      AccountsComponent
     
  ],
  imports: [
   // BrowserModule,
    AccountRoutingModule,
    CommonModule,
     HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    //environment.production ? HttpClientInMemoryWebApiModule.forRoot(PecuniaDataService, { delay: 1000 }) : []
  ],
  exports: [
    AccountsComponent,
    StartComponent
  ],
  providers: [],
 // bootstrap: [AccountComponent]
})
export class AccountModule { }
