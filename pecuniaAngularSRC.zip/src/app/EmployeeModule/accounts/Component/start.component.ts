import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { StartService } from '../Services/start.service';

@Component({
  selector: 'account-login',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.scss']
})
export class StartComponent implements OnInit
{
 
  constructor(private startService: StartService,private router: Router)
  {
    
  }

  ngOnInit()
  {
  }

  onStartClick()
  {
   
      this.router.navigate([ "account" ] );
      
  }
}



