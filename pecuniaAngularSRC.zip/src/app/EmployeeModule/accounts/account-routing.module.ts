import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StartComponent } from './Component/start.component';
import { AccountsComponent } from './Account/accounts.component';

const routes: Routes = [

  { path: "start", component: StartComponent },
  { path: "account", component: AccountsComponent },
   { path: "", redirectTo: "start", pathMatch: "full" }// loadChildren: () => import("./AccountModule/account.module").then(m => m.AccountModule) }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
