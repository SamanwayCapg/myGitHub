﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Controllers
{
    public class Account
    {
        public System.Guid AccountID { get; set; }
        public System.Guid CustomerID { get; set; }
        public Nullable<long> AccountNumber { get; set; }
        public Nullable<System.DateTime> DateOfCreation { get; set; }
        public string HomeBranch { get; set; }
        public string Feedback { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string AccountType { get; set; }
        public decimal Balance { get; set; }
    }
}