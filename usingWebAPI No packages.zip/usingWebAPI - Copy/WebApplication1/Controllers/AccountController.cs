﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace WebApplication1.Controllers
{
    public class AccountController : ApiController
    {
        [HttpGet]
        public IEnumerable<Account> GetAllAccounts()
        {
            HttpServer tt= new HttpServer();
            SqlConnection conn = new SqlConnection("Data Source=ndamssql\\sqlilearn;Initial Catalog=13th Aug CLoud PT Immersive;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            
            SqlDataAdapter adapter = new SqlDataAdapter("select * from TeamF.Account", conn);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);
           // System.Diagnostics.Debug.WriteLine("ip:"+HttpContext.Current.Request.UserHostAddress);

            List<Account> accounts = new List<Account>();

            DataRow datarow;
            for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
            {
                datarow = dataSet.Tables[0].Rows[i];
                Account account = new Account();

                account.AccountID = (Guid)datarow["AccountID"];
                account.AccountNumber = (long)datarow["AccountNumber"];
                account.DateOfCreation = (DateTime)datarow["DateOfCreation"];
                account.HomeBranch = (string)datarow["HomeBranch"];
                account.Feedback = (string)datarow["Feedback"];
                account.IsActive = (bool)datarow["IsActive"];
                account.Balance = (decimal)datarow["AccountBalance"];

                accounts.Add(account);
            }

            return accounts;
        }

        [HttpPost]
        public bool PostAccount(Account account)
        {
            //System.Diagnostics.Debug.WriteLine(account.CustomerID);
            //System.Diagnostics.Debug.WriteLine(account.HomeBranch);
            //System.Diagnostics.Debug.WriteLine(account.AccountType);
            //Account accountObject = new Account();
            SqlConnection conn = new SqlConnection("Data Source=ndamssql\\sqlilearn;Initial Catalog=13th Aug CLoud PT Immersive;Persist Security Info=True;User ID=sqluser;Password=sqluser");

            try
            {
                conn.Open();
                Console.WriteLine("connected to the database");
                SqlCommand com = new SqlCommand("TeamF.AddAccountDAL1", conn);

                Guid accountID = Guid.NewGuid();
                //Console.WriteLine(accountID);
                //Guid customerID;
                //Guid.TryParse("6E41CF21-1589-4581-9F59-2A327DD72F2D", out customerID);
                
                
                SqlParameter para1 = new SqlParameter("@AccountType", account.AccountType);
                SqlParameter para2 = new SqlParameter("@AccountNumber", 101);
                SqlParameter para3 = new SqlParameter("@AccountID", accountID);
                para3.SqlDbType = SqlDbType.UniqueIdentifier;
                SqlParameter para4 = new SqlParameter("@CustomerID", account.CustomerID);
                para4.SqlDbType = SqlDbType.UniqueIdentifier;
                SqlParameter para5 = new SqlParameter("@HomeBranch", account.HomeBranch);
                SqlParameter para6 = new SqlParameter("@IsActive", 1);
                List<SqlParameter> listOfParameters = new List<SqlParameter>();

                listOfParameters.Add(para1);
                listOfParameters.Add(para2);
                listOfParameters.Add(para3);
                listOfParameters.Add(para4);
                listOfParameters.Add(para5);
                listOfParameters.Add(para6);

                com.Parameters.AddRange(listOfParameters.ToArray());
                com.CommandType = CommandType.StoredProcedure;
                com.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch(Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                System.Diagnostics.Debug.WriteLine(e.StackTrace);
                return false;
            }
        }

        [HttpPut]
        public bool PutAccount(Account account)
        {
            //Account accountObject = new Account();
            System.Diagnostics.Debug.WriteLine(account.AccountID);

            SqlConnection conn = new SqlConnection("Data Source=ndamssql\\sqlilearn;Initial Catalog=13th Aug CLoud PT Immersive;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            try
            {
                conn.Open();
               
                SqlCommand com = new SqlCommand("TeamF.ChangeBranchOfAccount", conn);

               // Guid.TryParse("BE4DFF70-B3D5-48A6-B472-C38B4AE88D81", out Guid accID);
                SqlParameter para1 = new SqlParameter("@AccountID", account.AccountID);
                SqlParameter para2 = new SqlParameter("@HomeBranch", account.HomeBranch);

                List<SqlParameter> listOfParameters = new List<SqlParameter>();
                listOfParameters.Add(para1);
                listOfParameters.Add(para2);

                com.Parameters.AddRange(listOfParameters.ToArray());
                com.CommandType = CommandType.StoredProcedure;
                com.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                System.Diagnostics.Debug.WriteLine(e.StackTrace);
                return false;
            }

        }
    }
}
