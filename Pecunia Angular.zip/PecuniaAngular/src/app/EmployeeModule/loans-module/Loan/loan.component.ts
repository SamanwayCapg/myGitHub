import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'loan-root',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.scss']
})


export class LoanComponent {
  title = 'Loan Management System';
}
