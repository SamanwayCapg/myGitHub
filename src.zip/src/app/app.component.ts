﻿import { Component } from '@angular/core';
import {StartService} from './Services/start.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Pecunia';

   constructor(public startService: StartService)
  {
  }

}
