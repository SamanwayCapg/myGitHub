﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AccountRoutingModule } from './account-routing.module';
import { AccountsComponent } from './Account/accounts.component';

@NgModule({
  declarations: [
    AccountsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AccountRoutingModule,
  
  ],
   exports: [
    AccountRoutingModule,
    AccountsComponent
    
  ]
})
export class AccountModule { }

