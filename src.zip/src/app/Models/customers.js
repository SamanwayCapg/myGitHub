"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Customer = /** @class */ (function () {
    function Customer(Id, custID, custName, custMobile, custEmail) {
        this.id = Id;
        this.customerID = custID;
        this.customerName = custName;
        this.customerMobile = custMobile;
        this.customerEmail = custEmail;
    }
    return Customer;
}());
exports.Customer = Customer;
//# sourceMappingURL=customers.js.map