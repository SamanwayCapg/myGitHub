﻿ 
export class Account
{
  id: number;
  accountID: string;
  accountType:string;
  accountBranch:string;
  creationDateTime: string;
  lastModifiedDateTime: string;
  accountNumber: number;
  initialAmount: number;

  constructor(ID: number, AccountID: string, AccountType: string, AccountBranch: string, AccountNumber: number,  CreationDateTime: string, LastModifiedDateTime: string,InitialAmount:number)
  {
      this.id = ID;
      this.accountID = AccountID;
      this.accountType = AccountType;
      this.accountBranch = AccountBranch;
      this.creationDateTime = CreationDateTime;
      this.accountNumber = AccountNumber;
      this.initialAmount = InitialAmount;
      this.creationDateTime = CreationDateTime;
      this.lastModifiedDateTime = LastModifiedDateTime;
  }
}