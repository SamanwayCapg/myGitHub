import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ApplyLoanComponent } from './Components/ApplyLoan/applyLoan.component';
import { ApproveLoanComponent } from './Components/ApproveLoan/approveLoan.component';
import { ShowLoanComponent } from './Components/ShowLoan/showLoan.component';
import { LoanDataService } from './InMemoryWebAPIServices/loan-data.services';
import { environment } from '../environments/environment.prod';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApplyCarLoanComponent } from './Components/ApplyCarLoan/applyCarLoan.component';
import { ApplyEduLoanComponent } from './Components/ApplyEduLoan/applyEduLoan.component';
import { ApplyHomeLoanComponent } from './Components/ApplyHomeLoan/applyHomeLoan.component';

@NgModule({
  declarations: [
    AppComponent,
    ApplyCarLoanComponent,
    ApplyEduLoanComponent,
    ApplyHomeLoanComponent,
    ShowLoanComponent,
    ApproveLoanComponent
  ],

  imports: [
      FormsModule,
      ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
   
    environment.production ? HttpClientInMemoryWebApiModule.forRoot(LoanDataService, { delay: 1000 }) : [],
  ],

  providers: [],

  bootstrap: [AppComponent]
})
export class AppModule {

}
