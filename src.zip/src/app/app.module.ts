﻿import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {StartComponent} from './Component/start.component';
import {AccountModule} from './AccountModule/account.module';
import { HttpClientModule } from '@angular/common/http';
import { environment } from '../environments/environment.prod';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PecuniaDataService } from './InMemoryWebAPIServices/pecunia-data.service';


@NgModule({
  declarations: 
  [
    AppComponent,
    StartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AccountModule,
     HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    environment.production ? HttpClientInMemoryWebApiModule.forRoot(PecuniaDataService, { delay: 1000 }) : []
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
