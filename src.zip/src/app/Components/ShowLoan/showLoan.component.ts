import { Component } from '@angular/core'

@Component({
  selector: 'show-loan',
  templateUrl: './showLoan.component.html',
  styleUrls: ['./showLoan.component.scss']
})
export class ShowLoanComponent {

}
