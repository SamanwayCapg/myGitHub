import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StartComponent } from './Component/start.component';
import { AccountsComponent } from './Account/accounts.component';

const routes: Routes = [
 {path: "", redirectTo: "start", pathMatch: "full" },
  { path: "start", component: StartComponent },
  { path: "account", component: AccountsComponent }// loadChildren: () => import("./AccountModule/account.module").then(m => m.AccountModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
