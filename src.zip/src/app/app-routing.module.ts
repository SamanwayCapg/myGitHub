import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplyLoanComponent } from './Components/ApplyLoan/applyLoan.component';
import { ShowLoanComponent } from './Components/ShowLoan/showLoan.component';
import { ApproveLoanComponent } from './Components/ApproveLoan/approveLoan.component';
import { ApplyCarLoanComponent } from './Components/ApplyCarLoan/applyCarLoan.component';
import { ApplyEduLoanComponent } from './Components/ApplyEduLoan/applyEduLoan.component';
import { ApplyHomeLoanComponent } from './Components/ApplyHomeLoan/applyHomeLoan.component';

const routes: Routes = [
  { path: "showLoans", component: ShowLoanComponent },
  { path: "approveloans", component:ApproveLoanComponent },
  { path: "applycarloan", component: ApplyCarLoanComponent },
  { path: "applyhomeloan", component: ApplyHomeLoanComponent },
  { path: "applyeduloan", component: ApplyEduLoanComponent },
  //{ path: "", redirectTo: "ApplyNewLoan", pathMatch: "full" },
  { path: "**", redirectTo: "applyeduloan", pathMatch: "full" },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
