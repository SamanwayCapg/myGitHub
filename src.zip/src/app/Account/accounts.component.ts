import { Component, OnInit } from '@angular/core';
import { Account } from '../Models/account';
import { AccountsService } from '../Services/accounts.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
import { PecuniaComponentBase } from '../pecunia-component';


@Component
    (
    {
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
    }
    )

export class AccountsComponent extends PecuniaComponentBase implements OnInit
{
    accounts: Account[] = [];
    showAccountsSpinner: boolean = false;
  viewAccountCheckBoxes: any;
  accountTemp: Account[] = [];
    

    newAccountForm: FormGroup;
    newAccountDisabled: boolean = false;
    newAccountFormErrorMessages: any;
  
    editAccountForm: FormGroup;
    editAccountDisabled: boolean = false;
  editAccountFormErrorMessages: any;

  SearchAccountIDForm: FormGroup;
  displaySearch: boolean = false;
  displaySearchError: boolean = false;
  accountExist: boolean = false;

    deleteAccountForm: FormGroup;
    deleteAccountDisabled: boolean = false;

    constructor(private accountsService: AccountsService)
    {

        super();
        //Trail
        console.log("In Constructor");

        this.newAccountForm = new FormGroup(
            {
                accountType: new FormControl(null, [Validators.required]),
                accountBranch: new FormControl(null, [Validators.required]),
            initialAmount: new FormControl(null, [Validators.required, Validators.min(1000)]),
              customerID: new FormControl(null, [Validators.required])
            }
        );

        this.newAccountFormErrorMessages = {
            accountType: { required: "Account Type must be selected" },
            accountBranch: { required: "Account Branch must be selected" },
            initialAmount: { required: "Initial Amount is Mandatory", min: "Minimum amount is 1000rs" },
            customerID: {required:"Customer ID Mandatory For Creating Account"}
        };
        this.editAccountForm = new FormGroup({
            id: new FormControl(null),
            accountType: new FormControl(null, [Validators.required]),
            accountBranch: new FormControl(null, [Validators.required]),
            initialAmount: new FormControl(null, [Validators.required, Validators.min(1000)]),
            creationDateTime: new FormControl(null),
          accountID: new FormControl(null),
          customerID: new FormControl(null, [Validators.required])
        });

        this.editAccountFormErrorMessages = {
            accountType: { required: "Account Type must be selected" },
            accountBranch: { required: "Account Branch must be selected" },
            initialAmount: { required: "Initial Amount is Mandatory", min: "Minimum amount is 1000rs" }
        };


            this.viewAccountCheckBoxes = {
                accountType: true,
                accountBranch: true,
                initialAmount: true,
                accountID: true,
                lastModifiedOn: true
            };

            this.deleteAccountForm = new FormGroup({
                id: new FormControl(null),
                accountID: new FormControl(null),
                accountType: new FormControl(null)
      });

      this.SearchAccountIDForm = new FormGroup(
        {
          searchBox: new FormControl(null)
        });


        }
   

  ngOnInit() 
  {
     
      this.showAccountsSpinner = true;
      this.accountsService.GetAllAccounts().subscribe((response) =>
      {
          this.accounts = response;
          //trial
          console.log(this.accounts);
          this.showAccountsSpinner = false;
      }, (error) =>
      {
          console.log(error);
      })
  }
  onCreateAccountClick() {
      this.newAccountForm.reset();
      this.newAccountForm["submitted"] = false;
  }
  onAddAccountClick(event)
  {
      this.newAccountForm["Submitted"] = true;
      if (this.newAccountForm.valid)
      {
          this.newAccountDisabled = true;
          var account: Account = this.newAccountForm.value;
          console.log(account.accountType);
          console.log(this.newAccountForm.value);

          this.accountsService.AddAccount(account).subscribe((addresponse) => {
              this.newAccountForm.reset();
              $("#btnAddAccountCancel").trigger("click");
              this.newAccountDisabled = false;
              this.showAccountsSpinner = true;

              this.accountsService.GetAllAccounts().subscribe((getResponse) => {
                  this.showAccountsSpinner = false;
                  this.accounts = getResponse;
              }, (error) => {
                  console.log(error);
              });

          },
              (error) => {
                  console.log(error);
                  this.newAccountDisabled = false;
              });
      }

      else {
          super.getFormGroupErrors(this.newAccountForm); 
      }
          
  }

  getFormControlCssClass(formControl: FormControl, formGroup: FormGroup): any {
      return {
          'is-invalid': formControl.invalid && (formControl.dirty || formControl.touched || formGroup["submitted"]),
          'is-valid': formControl.valid && (formControl.dirty || formControl.touched || formGroup["submitted"])
      };
  }

  getFormControlErrorMessage(formControlName: string, validationProperty: string): string {
      return this.newAccountFormErrorMessages[formControlName][validationProperty];
  }

  getCanShowFormControlErrorMessage(formControlName: string, validationProperty: string, formGroup: FormGroup): boolean {
      return formGroup.get(formControlName).invalid && (formGroup.get(formControlName).dirty || formGroup.get(formControlName).touched || formGroup['submitted']) && formGroup.get(formControlName).errors[validationProperty];
  }

  onEditAccountClick(index) {
      this.editAccountForm.reset();
      this.editAccountForm["submitted"] = false;
      this.editAccountForm.patchValue({
          id: this.accounts[index].id,
          accountID: this.accounts[index].accountID,
          accountType: this.accounts[index].accountType,
          accountBranch: this.accounts[index].accountBranch,
          initialAmount:this.accounts[index].initialAmount,
          creationDateTime: this.accounts[index].creationDateTime
      });
  }


  onUpdateAccountClick(event) {
      this.editAccountForm["submitted"] = true;
      if (this.editAccountForm.valid) {
          this.editAccountDisabled = true;
          var account: Account = this.editAccountForm.value;

          this.accountsService.UpdateAccount(account).subscribe((updateResponse) => {
              this.editAccountForm.reset();
              $("#btnUpdateAccountCancel").trigger("click");
              this.editAccountDisabled = false;
              this.showAccountsSpinner = true;

              this.accountsService.GetAllAccounts().subscribe((getResponse) => {
                  this.showAccountsSpinner = false;
                  this.accounts = getResponse;
              }, (error) => {
                      console.log(error);
                  });
          },
              (error) => {
                  console.log(error);
                  this.editAccountDisabled = false;
              });
      }
      else {
          super.getFormGroupErrors(this.editAccountForm);
      }
  }

  onDeleteAccountClick(index) {
      this.deleteAccountForm.reset();
      this.deleteAccountForm["submitted"] = false;
      this.deleteAccountForm.patchValue({
          id: this.accounts[index].id,
          accountID: this.accounts[index].accountID,
          accountType: this.accounts[index].accountType
      });
  }

  onDeleteAccountConfirmClick(event) {
      this.deleteAccountForm["submitted"] = true;
      if (this.deleteAccountForm.valid) {
          this.deleteAccountDisabled = true;
          var account: Account = this.deleteAccountForm.value;

          this.accountsService.DeleteAccount(account.accountID, account.id).subscribe((deleteResponse) => {
              this.deleteAccountForm.reset();
              $("#btnDeleteAccountCancel").trigger("click");
              this.deleteAccountDisabled = false;
              this.showAccountsSpinner = true;

              this.accountsService.GetAllAccounts().subscribe((getResponse) => {
                  this.showAccountsSpinner = false;
                  this.accounts = getResponse;
              }, (error) => {
                      console.log(error);
                  });
          },
              (error) => {
                  console.log(error);
                  this.deleteAccountDisabled = false;
              });
      }
      else {
          super.getFormGroupErrors(this.deleteAccountForm);
      }
  }

  onViewSelectAllClick() {
      for (let propertyName of Object.keys(this.viewAccountCheckBoxes)) {
          this.viewAccountCheckBoxes[propertyName] = true;
      }
  }

  onViewDeselectAllClick()
  {
      for (let propertyName of Object.keys(this.viewAccountCheckBoxes)) {
          this.viewAccountCheckBoxes[propertyName] = false;
      }
  }

  onSearchAccountClick()
  {
 
    console.log("In Search Account");
    console.log(this.SearchAccountIDForm.value.searchBox);
    this.accountsService.GetAccountByAccountID(this.SearchAccountIDForm.value.searchBox).subscribe((response) =>
    {
    
      this.accountTemp = response;
      console.log(this.accountTemp);
      if (response.length > 0)
      {
        console.log("Account Found");
        this.displaySearch = true;
      }
     
      else
        this.displaySearchError = true;

      console.log("Display Search true");


    }
      , (error) => {

      });

  }
  onOuterSearchClick()
  {
    this.SearchAccountIDForm.reset();
  }
  onResetClick() {
    this.displaySearch = false;
    this.SearchAccountIDForm.reset();
    this.displaySearchError = false;
  }

  CheckIfAccountExist() {
    this.accountExist = false;
    this.accountsService.GetAccountByCustomerID(this.newAccountForm.value.customerID).subscribe((response) => {

      if (response.length > 0) 
      this.accountExist = true;
    }, (error) =>
    {
      console.log(error);
    });
  }


  }


