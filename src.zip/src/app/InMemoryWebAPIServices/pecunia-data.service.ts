﻿import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Account } from '../Models/account';

@Injectable({
  providedIn: 'root'
})
export class PecuniaDataService implements InMemoryDbService
{
  constructor() { }

  createDb()
  {
   
      let accounts = [
          new Account(1, "101", "Savings", "Pune", 500001, "10/3/2019", "11/3/2019",1000),
          new Account(2, "102", "Savings", "Mumbai", 500002, "10/3/2019", "11/3/2019",2000)
    ];

   

    return { accounts };
  }
}


