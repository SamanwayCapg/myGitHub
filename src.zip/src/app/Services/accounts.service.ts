﻿import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from '../Models/account';



@Injectable({
    providedIn: 'root'
})
export class AccountsService
{
    constructor(private httpClient: HttpClient)
    {

    }
    AddAccount(account : Account): Observable<boolean>
    {
        account.creationDateTime = new Date().toLocaleDateString();
        account.lastModifiedDateTime = new Date().toLocaleDateString();
        account.accountID = this.uuidv4();
        console.log("In Add Account");
        
        return this.httpClient.post<boolean>(`/api/accounts`, account);
    }
    GetAllAccounts(): Observable<Account[]>
    {
        return this.httpClient.get<Account[]>(`/api/accounts`);
    }
    UpdateAccount(account: Account): Observable<boolean> {
        account.lastModifiedDateTime = new Date().toLocaleDateString();
        return this.httpClient.put<boolean>(`/api/accounts`, account);
    }

    DeleteAccount(accountID: string, id: number): Observable<boolean>
    {
        return this.httpClient.delete<boolean>(`/api/accounts/${id}`);
    }

    GetAccountByAccountID(AccountID: number): Observable<Account>
    {
        return this.httpClient.get<Account>(`/api/accounts?accountID=${AccountID}`);
    }
   
    uuidv4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
    }
