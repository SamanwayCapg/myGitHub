﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PresentationASP
{
    public partial class Loans : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void searchBtn_Click(object sender, EventArgs e)
        {
         //   if (selectID.SelectedItem.Value.Equals("1") == true)
                //TextBox1.Text = "1 selected";
        }

        protected void IDTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}