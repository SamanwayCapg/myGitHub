﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pecunia.MVC.Models
{
    public class HomeLoanViewModel
    {
    }
}