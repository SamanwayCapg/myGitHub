﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pecunia.PresentationMVC.Models
{
    public class ShowMessageModel
    {
        public string Message { get; set; }
    }
}